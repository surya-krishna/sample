var app = angular.module("airbus", ["ngRoute"]);
app.config(function($routeProvider) {
    $routeProvider
    .when("/", {
        controller : "loginController",
        controllerAs : "lc",
        templateUrl : "login/login.html"
    })
    .when("/book", {
        controller : "bookController",
        controllerAs : "bo",
        templateUrl : "book/book.html"
    })
});