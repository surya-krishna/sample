app.service("sevicecall",function($http){
    return {
        httpCall: function(endpoint,type,input,successCallback,errorCallback){
            var req = {
                method: type,
                url: properties["serviceUrl"]+endpoint,
                headers: {
                  'Content-Type': 'application/json'
                },
                data: input
               }
              return $http(req).then(successCallback,errorCallback);   
        }
    };
});