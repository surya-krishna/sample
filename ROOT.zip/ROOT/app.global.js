var properties={};
properties["serviceUrl"]="http://100.82.193.52:8080/";
properties["title"]="Airbus";
properties["token"]="";

