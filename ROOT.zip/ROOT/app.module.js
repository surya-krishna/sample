app.controller("bodyController",['$scope','$rootScope',function($scope,$rootScope){
    var bdc=this;
    bdc.title=properties["title"];

}]);