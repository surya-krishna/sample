app.controller('loginController',['$scope','$http',function($scope, $http){
    var lc=this;
    lc.userDetails={};
    lc.userDetails.username="a";
    lc.userDetails.password="a";
    lc.errorMsg="";
    lc.login=function(){
        function successLogin(response){
            $rootScope.userDetails=response.data;
            lc.errorMsg=response.data.errMsg;
            $location.path("/book");
        }
        function errorLogin(response){
            lc.errorMsg="Something Went Wrong";
        }
        var req = {
            method: 'POST',
            url: properties["serviceUrl"]+"authenticate",
            headers: {
              'Content-Type': 'application/json'
            },
            data: lc.userDetails
           }
          return $http(req).then(successLogin,errorLogin); 
    }
}]);