app.controller('bookController',['$scope','$http',function($scope, $http){
    var bo=this;
    bo.bookingIp={};
    bo.bookingIp.from="";
    bo.bookingIp.to="";
    bo.bookingIp.bookingDate="";
    bo.errorMsg="";
    bo.flights=[];

    /*var flightData={
        flightId:"123",
        flightNo:"AB213",
        flightName:"Airbus",
        from:"hyderabad",
        to:"banglore",
        arrivalTime:"11:00",
        depatureTime:"11:35",
        bookingDate:"2019-12-20",
        price:"Rs.3543"
    };
    
    var flightData2={
        flightId:"124",
        flightNo:"AB214",
        flightName:"Airbus",
        from:"hyderabad",
        to:"chennai",
        arrivalTime:"12:00",
        depatureTime:"12:35",
        bookingDate:"2019-12-21",
        price:"Rs.3343"
    };
    bo.flights.push(flightData);
    bo.flights.push(flightData2);
*/
    bo.getFlights=function(){
        bo.bookingIp.bookingDate=bo.bookingIp.bookingDate.getFullYear()+"-"+bo.bookingIp.bookingDate.getMonth()+"-"+bo.bookingIp.bookingDate.getDate();
        function successCallback(response){
            bo.flights=response.data;
        }
        function errorCallback(response){
            bo.errorMsg="Something Went Wrong";
        }
        var req = {
            method: 'POST',
            url: properties["serviceUrl"]+"getFlights",
            headers: {
              'Content-Type': 'application/json',
              'token':$rootScope.userDetails.token
            },
            data: bo.bookingIp
           }
          return $http(req).then(successCallback,errorCallback); 
    };
    bo.book=function(flightId){
        
        function successCallback(response){
            bo.successMsg=response.data.successMsg;
            angular.element("#myModal").modal();
        }
        function errorCallback(response){
            bo.errorMsg="Something Went Wrong";
        }
        var req = {
            method: 'POST',
            url: properties["serviceUrl"]+"bookTicket",
            headers: {
              'Content-Type': 'application/json',
              'token':$rootScope.userDetails.token
            },
            data: {"flightId":flightId}
           }
          return $http(req).then(successCallback,errorCallback);
    }
}]);